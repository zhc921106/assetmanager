function myadd(x, y)
	print("Documents version2")
    return x + y 
end
