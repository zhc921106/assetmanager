function myadd(x, y)
	print("luaScript version 3")
    return x + y
end