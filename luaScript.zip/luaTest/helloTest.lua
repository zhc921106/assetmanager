function myadd(x, y)
	print("luaScript")
    return x + y
end