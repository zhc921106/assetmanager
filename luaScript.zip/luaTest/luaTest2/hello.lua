function myadd(x, y)
	print("luaTest,luaTest2,hello")
    return x + y
end